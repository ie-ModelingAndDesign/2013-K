//
//  AppDelegate.h
//  stopWatchView
//
//  Created by たかひろ　あふそ on 2013/11/30.
//  Copyright (c) 2013年 たかひろ　あふそ. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
