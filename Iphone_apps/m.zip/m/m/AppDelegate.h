//
//  AppDelegate.h
//  m
//
//  Created by たかひろ　あふそ on 2013/12/05.
//  Copyright (c) 2013年 たかひろ　あふそ. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
