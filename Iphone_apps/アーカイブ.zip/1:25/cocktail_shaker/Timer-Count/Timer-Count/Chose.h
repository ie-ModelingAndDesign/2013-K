//
//  Chose.h
//  Timer-Count
//
//  Created by たかひろ　あふそ on 2014/01/23.
//  Copyright (c) 2014年 Takumi ITO. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Chose : UIViewController
    
@end
