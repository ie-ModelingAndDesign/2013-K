//
//  RecordViewController.h
//  Timer-Count
//
//  Created by Takumi ITO on 2013/12/06.
//  Copyright (c) 2013年 Takumi ITO. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RecordViewController : UIViewController
@property (weak, nonatomic) IBOutlet UILabel *Record;
@property int score;
@property int button_n;
    
@property (weak, nonatomic) IBOutlet UILabel *name;
    
@property (weak, nonatomic) IBOutlet UILabel *Total;
@end
