//
//  Record.h
//  Timer-Count
//
//  Created by Takumi ITO on 2013/12/06.
//  Copyright (c) 2013年 Takumi ITO. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Record : NSObject

@end
